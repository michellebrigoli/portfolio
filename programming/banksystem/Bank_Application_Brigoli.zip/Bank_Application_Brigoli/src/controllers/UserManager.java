
package controllers;

public class UserManager {
     private static String username;
    private static double balance;
    private static String acc_num;

    public static void setAcc_num(String acc_num) {
        UserManager.acc_num = acc_num;
    }

    public static String getAcc_num() {
        return acc_num;
    }
    public static String getBalance(){
        return Double.toString(balance);
    }
    public static void setBalance(double balance){
        UserManager.balance = balance;
    }
    public static void setUsername(String username){
        UserManager.username = username;
    }
    
    public static String getUsername(){
        return username;
    }
    
    public static void Deposit(double amount){
        balance += amount;
    }
    
    public static void Withdraw (double amount){
        balance -= amount;
    }
    
    public static void Transfer (double amount){
        balance -= amount;
    }
}