﻿using System.Collections.Generic;

namespace HangmanGame
{
    public class GameModel
    {
        public const int MAX_GUESSES = 6;
        public readonly Dictionary<string, string[]> WordCategories = new Dictionary<string, string[]>
        {
            {"Easy", new string[] {"bit", "bug", "cpu", "cpe", "net", "ram", "code", "data", "file", "loop"}},
            {"Medium", new string[] {"binary", "hacker", "laptop", "memory", "reboot", "server", "python", "syntax", "variable", "function"}},
            {"Hard", new string[] {"algorithm", "flowchart", "interface", "iterative", "software", "hardware", "database", "compiler", "debugging", "encryption"}}
        };

        public readonly Dictionary<string, int> DifficultyPoints = new Dictionary<string, int>
        {
            {"Easy", 3},
            {"Medium", 5},
            {"Hard", 10}
        };
    }
}