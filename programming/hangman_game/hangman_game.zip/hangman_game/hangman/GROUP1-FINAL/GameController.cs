﻿using System;

namespace HangmanGame
{
    public class GameController
    {
        private readonly GameView _view;
        private readonly GameModel _model;

        public GameController()
        {
            _view = new GameView();
            _model = new GameModel();
        }

        public void Run()
        {
            _view.ShowWelcomeBanner(); 

            while (true)
            {
                _view.ShowMainMenu(); 
                int choice = _view.GetMenuChoice();

                switch (choice)
                {
                    case 1:
                        StartGame();
                        break;
                    case 2:
                        _view.ShowAbout();
                        break;
                    case 3:
                        _view.ShowInstructions();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                }
            }
        }


        private void StartGame()
        {
            int modeChoice = _view.GetGameModeChoice();

            if (modeChoice == 1)
            {
                var singlePlayer = new SinglePlayer(_model, _view);
                singlePlayer.Play();
            }
            else if (modeChoice == 2)
            {
                var multiPlayer = new MultiPlayer(_model, _view);
                multiPlayer.Play();
            }
        }
    }
}