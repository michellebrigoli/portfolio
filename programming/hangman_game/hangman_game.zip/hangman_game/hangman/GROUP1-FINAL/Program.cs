﻿using System;

namespace HangmanGame
{
    class Program
    {
        static void Main(string[] args)
        {
            GameController game = new GameController();
            game.Run();
        }
    }
}

