﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Metrics;
using System.Diagnostics;
using System.Drawing;
using System.Net.Sockets;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics.X86;
using System.Threading.Channels;
using System.Timers;
using System.Threading;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace HangmanGame
{
    public class GameView
    {
        private string GetCenteredText(string text)
        {
            int windowWidth = Console.WindowWidth;
            int padding = (windowWidth - text.Length) / 2;
            return new string(' ', padding) + text;
        }

        public static void PrintWriteCentered(string text)
        {
            int windowWidth = Console.WindowWidth;
            int centeredPosition = (windowWidth - text.Length) / 2;
            Console.SetCursorPosition(Math.Max(centeredPosition, 0), Console.CursorTop);
            Console.Write(text);
        }

        public void PrintCentered(string text)
        {
            int windowWidth = Console.WindowWidth;
            int centeredPosition = (windowWidth - text.Length) / 2;
            Console.SetCursorPosition(Math.Max(centeredPosition, 0), Console.CursorTop);
            Console.WriteLine(text);
        }

        public void ShowWelcomeBanner()
        {
            bool isBright = false;
            
            void DrawBanner(ConsoleColor color)


            {
                Console.Clear();  // Clear console to refresh colors
                Console.SetCursorPosition(0, 10);
                Console.ForegroundColor = color;
                Console.WriteLine("         ╔─────────────────────────────────────────────────────────────────────────────────────────────────────╗");
                Console.WriteLine("         │ █████   █████   █████████   ██████   █████   █████████  ██████   ██████   █████████   ██████   █████│");
                Console.WriteLine("         │░░███   ░░███   ███░░░░░███ ░░██████ ░░███   ███░░░░░███░░██████ ██████   ███░░░░░███ ░░██████ ░░███ │");
                Console.WriteLine("         │ ░███    ░███  ░███    ░███  ░███░███ ░███  ███     ░░░  ░███░█████░███  ░███    ░███  ░███░███ ░███ │");
                Console.WriteLine("         │ ░███████████  ░███████████  ░███░░███░███ ░███          ░███░░███ ░███  ░███████████  ░███░░███░███ │");
                Console.WriteLine("         │ ░███░░░░░███  ░███░░░░░███  ░███ ░░██████ ░███    █████ ░███ ░░░  ░███  ░███░░░░░███  ░███ ░░██████ │");
                Console.WriteLine("         │ ░███    ░███  ░███    ░███  ░███  ░░█████ ░░███  ░░███  ░███      ░███  ░███    ░███  ░███  ░░█████ │");
                Console.WriteLine("         │ █████   █████ █████   █████ █████  ░░█████ ░░█████████  █████     █████ █████   █████ █████  ░░█████│");
                Console.WriteLine("         │░░░░░   ░░░░░ ░░░░░   ░░░░░ ░░░░░    ░░░░░   ░░░░░░░░░  ░░░░░     ░░░░░ ░░░░░   ░░░░░ ░░░░░    ░░░░░ │");
                Console.WriteLine("         ╚─────────────────────────────────────────────────────────────────────────────────────────────────────╝");
                Console.ResetColor();
            }
            // Draw the initial banner
            Console.Clear();
            DrawBanner(ConsoleColor.Yellow);

            // Display the "Press any key to continue..." message below the banner
            Console.SetCursorPosition(0, 22);  // Adjust the position below the banner
            Console.ForegroundColor = ConsoleColor.DarkGreen;
           // Console.WriteLine("   Press any key to continue........");

            // Timer for blinking effect (only changes color)
            System.Timers.Timer blinkTimer = new System.Timers.Timer(300);
            blinkTimer.Elapsed += (sender, e) =>
            {
                isBright = !isBright;
                DrawBanner(isBright ? ConsoleColor.Red : ConsoleColor.Yellow);
            };

            blinkTimer.Start();

            Console.ReadKey();

            // Stop the blinking once the key is pressed
            blinkTimer.Stop();
            blinkTimer.Dispose();

            Console.ResetColor();
        }






        public void ShowMainMenu()
        {
            Console.Clear();
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Magenta;
            PrintCentered("                              ╔──────────────────────────────────╗                      ");
            PrintCentered("                              │░█▀▀░█▀█░█▄█░█▀▀░░░█▄█░█▀▀░█▀█░█░█│                      ");
            PrintCentered("                              │░█░█░█▀█░█░█░█▀▀░░░█░█░█▀▀░█░█░█░█│                      ");
            PrintCentered("                              │░▀▀▀░▀░▀░▀░▀░▀▀▀░░░▀░▀░▀▀▀░▀░▀░▀▀▀│                      ");
            PrintCentered("                              ╚──────────────────────────────────╝                      ");
            Console.ResetColor();                                                                                  
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            PrintCentered("                          ┌─  ╦  ─┐     ╔═╗╔╦╗╔═╗╦═╗╔╦╗  ╔═╗╔═╗╔╦╗╔═╗                   ");
            PrintCentered("                          │   ║   │     ╚═╗ ║ ╠═╣╠╦╝ ║   ║ ╦╠═╣║║║║╣                    ");
            PrintCentered("                          └─  ╩  ─┘     ╚═╝ ╩ ╩ ╩╩╚═ ╩   ╚═╝╩ ╩╩ ╩╚═╝                   ");
                                                                                         
            PrintCentered("                          ┌─  ╦╦  ─┐    ╔═╗╔╗ ╔═╗╦ ╦╔╦╗                                 ");
            PrintCentered("                          │   ║║   │    ╠═╣╠╩╗║ ║║ ║ ║                                  ");
            PrintCentered("                          └─  ╩╩  ─┘    ╩ ╩╚═╝╚═╝╚═╝ ╩                                  ");
                                                                                                                                        
            PrintCentered("                         ┌─  ╦╦╦  ─┐    ╦╔╗╔╔═╗╔╦╗╦═╗╦ ╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗                ");  
            PrintCentered("                         │   ║║║   │    ║║║║╚═╗ ║ ╠╦╝║ ║║   ║ ║║ ║║║║╚═╗                ");
            PrintCentered("                         └─  ╩╩╩  ─┘    ╩╝╚╝╚═╝ ╩ ╩╚═╚═╝╚═╝ ╩ ╩╚═╝╝╚╝╚═╝                ");                                                                           
                                                                                                                                        
            PrintCentered("                        ┌─  ╦╦  ╦  ─┐   ╔═╗═╗ ╦╦╔╦╗                                     "); 
            PrintCentered("                        │   ║╚╗╔╝   │   ║╣ ╔╩╦╝║ ║                                      ");
            PrintCentered("                        └─  ╩ ╚╝   ─┘   ╚═╝╩ ╚═╩ ╩                                      ");
           Console.ResetColor();
        }

        public int GetMenuChoice()
        {
            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(intercept: true); // No echo, immediate response

                if (char.IsDigit(key.KeyChar))
                {
                    int choice = key.KeyChar - '0'; // Convert char to int (e.g., '1' → 1)
                    if (choice >= 1 && choice <= 4)
                    {
                        Console.WriteLine(); // Move to the next line after selection
                        return choice;
                    }
                }

                // Optional: Play a "beep" sound for invalid input
                Console.Beep();
            }
        }

        public int GetGameModeChoice()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            PrintCentered("                       ╔══════════════════════════════════╗                ");
            PrintCentered("                       ║░█▀▀░█▀█░█▄█░█▀▀░░░█▄█░█▀█░█▀▄░█▀▀║                ");
            PrintCentered("                       ║░█░█░█▀█░█░█░█▀▀░░░█░█░█░█░█░█░█▀▀║                ");
            PrintCentered("                       ║░▀▀▀░▀░▀░▀░▀░▀▀▀░░░▀░▀░▀▀▀░▀▀░░▀▀▀║                ");
            PrintCentered("                       ╚══════════════════════════════════╝                ");

            Console.ResetColor();                                    
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            PrintCentered("                 ┌─  ╦  ─┐  ╔═╗╦╔╗╔╔═╗╦  ╔═╗  ╔═╗╦  ╔═╗╦ ╦╔═╗╦═╗            ");
            PrintCentered("                 │   ║   │  ╚═╗║║║║║ ╦║  ║╣   ╠═╝║  ╠═╣╚╦╝║╣ ╠╦╝            ");
            PrintCentered("                 └─  ╩  ─┘  ╚═╝╩╝╚╝╚═╝╩═╝╚═╝  ╩  ╩═╝╩ ╩ ╩ ╚═╝╩╚═            ");
                                                                                                                            
            PrintCentered("                 ┌─  ╦╦  ─┐  ╔╦╗╦ ╦╦ ╔╦╗╦╔═╗╦  ╔═╗╦ ╦╔═╗╦═╗                 ");
            PrintCentered("                 │   ║║   │  ║║║║ ║║  ║ ║╠═╝║  ╠═╣╚╦╝║╣ ╠╦╝                 ");
            PrintCentered("                 └─  ╩╩  ─┘  ╩ ╩╚═╝╩═╝╩ ╩╩  ╩═╝╩ ╩ ╩ ╚═╝╩╚═                 ");                                                           
                                                                                                                            
            PrintCentered("                 ┌─  ╦╦╦  ─┐  ╔╗ ╔═╗╔═╗╦╔═  ╔╦╗╔═╗  ╔╦╗╔═╗╔╗╔╦ ╦            ");
            PrintCentered("                 │   ║║║   │  ╠╩╗╠═╣║  ╠╩╗   ║ ║ ║  ║║║║╣ ║║║║ ║            ");
            PrintCentered("                 └─  ╩╩╩  ─┘  ╚═╝╩ ╩╚═╝╩ ╩   ╩ ╚═╝  ╩ ╩╚═╝╝╚╝╚═╝            ");
            Console.ResetColor();




            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(intercept: true); // No echo, immediate response

                if (char.IsDigit(key.KeyChar))
                {
                    int choice = key.KeyChar - '0'; // Convert char to int (e.g., '1' → 1)
                    if (choice >= 1 && choice <= 4)
                    {
                        Console.Clear(); // Move to the next line after selection
                        return choice;
                    }
                }

                // Optional: Play a "beep" sound for invalid input
                Console.Beep();
            }
        }
        public void ShowAbout()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n");
            PrintCentered("                                             ╔════════════════════╗                                              ");
            PrintCentered("                                             ║░█▀█░█▀█░█▀█░█░█░▀█▀║                                              ");
            PrintCentered("                                             ║░█▀█░█▀█░█░█░█░█░░█░║                                              ");
            PrintCentered("                                             ║░▀░▀░▀▀▀░▀▀▀░▀▀▀░░▀░║                                              ");
            PrintCentered("                                             ╚════════════════════╝                                              ");                                                    
            Console.ResetColor();
            Console.WriteLine("\n");

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            PrintCentered("                           ┌──────────────────────────────────────────────────────────┐                          ");
            PrintCentered("                           │     Developer: Al Vincent Fabrique                       │                          ");
            PrintCentered("                           │     Age: 22                                              │                          ");
            PrintCentered("                           │     Status: Single                                       │                          ");
            PrintCentered("                           │     Motto: 'Life is short but my patience is shorter'    │                          ");
            PrintCentered("                           └──────────────────────────────────────────────────────────┘                          ");
                                                                                                                  
            PrintCentered("  ┌─────────────────────────────────────────┐                         ┌───────────────────────────────────────┐  ");
            PrintCentered("  │     Developer: Michelle Brigoli         │                         │     Developer: Jacenfa Dayangco       │  ");
            PrintCentered("  │     Age: 20                             │                         │     Age: 21                           │  ");
            PrintCentered("  │     Status: Single                      │                         │     Status: Single                    │  ");
            PrintCentered("  │     Motto: 'I believe I can FLY'        │                         │     Motto: 'To see is to BELIEVE!'    │  ");
            PrintCentered("  └─────────────────────────────────────────┘                         └───────────────────────────────────────┘  ");
            Console.ResetColor();

            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Gray;
            PrintCentered("This Hangman game was developed as a programming project. ");                                                      
            PrintCentered("Version: CPE-PC 332   ");                                                      
            PrintCentered("Release Date: April 2025    ");                                                      
            PrintCentered("====================================    ");
            Console.ResetColor();
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Green;
            PrintCentered("   Press any key to continue........");
            Console.ResetColor();
            Console.ReadKey();
            
        }
        public void ShowInstructions()
        {
       Console.Clear();
       Console.ForegroundColor = ConsoleColor.Magenta;
       Console.WriteLine("\n");
       Console.WriteLine(GetCenteredText("                             ┌────────────────────────────────────────────────┐                                 "));
       Console.WriteLine(GetCenteredText("                             │░▀█▀░█▀█░█▀▀░▀█▀░█▀▄░█░█░█▀▀░▀█▀░▀█▀░█▀█░█▀█░█▀▀│                                 "));
       Console.WriteLine(GetCenteredText("                             │░░█░░█░█░▀▀█░░█░░█▀▄░█░█░█░░░░█░░░█░░█░█░█░█░▀▀█│                                 "));
       Console.WriteLine(GetCenteredText("                             │░▀▀▀░▀░▀░▀▀▀░░▀░░▀░▀░▀▀▀░▀▀▀░░▀░░▀▀▀░▀▀▀░▀░▀░▀▀▀│                                 "));
       Console.WriteLine(GetCenteredText("                             └────────────────────────────────────────────────┘                                 "));
       Console.WriteLine("\n");
       Console.ResetColor();
       Console.ForegroundColor = ConsoleColor.Cyan;
       Console.WriteLine(GetCenteredText("                                       HANGMAN: THE FINAL GUESS!                                         "));
       Console.WriteLine(GetCenteredText("     Every letter guessed is a step closer to victory—or the final stand. Choose wisely!  "));
       Console.ResetColor();
       Console.WriteLine("\n");
       Console.ForegroundColor = ConsoleColor.DarkCyan;
       Console.WriteLine(GetCenteredText("   ┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐   "));
       Console.WriteLine(GetCenteredText("   │ In Single Player Mode, the game picks a mystery word, and you must guess the letters correctly         │   "));
       Console.WriteLine(GetCenteredText("   │ to fill in the blanks. Wrong guesses cost lives, and too many mistakes spell defeat.Feeling stuck?     │   "));
       Console.WriteLine(GetCenteredText("   │ Use a hint to reveal a letter—at a cost! In Multiplayer Mode, one player becomes the Wordmaster,       │   "));
       Console.WriteLine(GetCenteredText("   │ choosing the word, while the other plays as the Challenger, guessing letters to crack the code.        │   "));
       Console.WriteLine(GetCenteredText("   │ The Wordmaster can drop hints—either helpful or deceptive. Swap roles and keep the competition alive!  │   "));
       Console.WriteLine(GetCenteredText("   │ Will you be the last letter standing? Let the game begin!                                              │   "));
       Console.WriteLine(GetCenteredText("   └────────────────────────────────────────────────────────────────────────────────────────────────────────┘   "));
       Console.ResetColor();
       Console.WriteLine("\n");
       Console.ForegroundColor = ConsoleColor.Green;
       Console.WriteLine(GetCenteredText("Press any key to return to main menu....."));
       Console.ResetColor();
       Console.ReadKey();
       Console.Clear();
        }

        public string GetPlayerName(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        public string GetWordToGuess(string playerName)
        {
            while (true) // Keep asking until valid input is provided
            {
                Console.WriteLine("\n");
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.Write($"{playerName}, enter a word (max 10 letters) for the other player to guess: ");
                Console.ResetColor();
                string input = Console.ReadLine()?.ToLower().Trim();

                if (string.IsNullOrEmpty(input))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Error: Word cannot be empty. Please try again.");
                    Console.ResetColor();
                    continue;
                }

                if (input.Length > 10)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Error: Word must be 10 letters or fewer. Please try again.");
                    Console.ResetColor();
                    continue;
                }

                // Check if all characters are letters
                if (!input.All(char.IsLetter))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Error: Word should contain only letters. Please try again.");
                    Console.ResetColor();
                    continue;
                }

                return input;
            }
        }

        public char GetLetterGuess(string playerName, string hiddenWord, int guessesLeft)
        {
            Console.WriteLine($"\n{playerName}, you have {guessesLeft} guesses left");
            Console.Write($"Guess a letter ({hiddenWord}): ");
            char letter;
            while (!char.TryParse(Console.ReadLine(), out letter) || !char.IsLetter(letter))
            {
                Console.Write("Invalid input. Please enter a single letter: ");
            }
            return char.ToLower(letter);
        }


        public int GetDifficultyChoice()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(GetCenteredText("                    ╔════════════════════════════════════════╗                     "));   
            Console.WriteLine(GetCenteredText("                    ║░█▀▄░▀█▀░█▀▀░█▀▀░▀█▀░█▀▀░█░█░█░░░▀█▀░█░█║                     "));
            Console.WriteLine(GetCenteredText("                    ║░█░█░░█░░█▀▀░█▀▀░░█░░█░░░█░█░█░░░░█░░░█░║                     "));
            Console.WriteLine(GetCenteredText("                    ║░▀▀░░▀▀▀░▀░░░▀░░░▀▀▀░▀▀▀░▀▀▀░▀▀▀░░▀░░░▀░║                     "));
            Console.WriteLine(GetCenteredText("                    ╚════════════════════════════════════════╝                     "));
            Console.ResetColor();
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(GetCenteredText("                           ┌─  ╦  ─┐  ╔═╗╔═╗╔═╗╦ ╦                                 "));
            Console.WriteLine(GetCenteredText("                           │   ║   │  ║╣ ╠═╣╚═╗╚╦╝                                 "));
            Console.WriteLine(GetCenteredText("                           └─  ╩  ─┘  ╚═╝╩ ╩╚═╝ ╩                                  "));
                                                                                                                             
            Console.WriteLine(GetCenteredText("                           ┌─  ╦╦  ─┐  ╔╦╗╔═╗╔╦╗╦╦ ╦╔╦╗                            "));
            Console.WriteLine(GetCenteredText("                           │   ║║   │  ║║║║╣  ║║║║ ║║║║                            "));
            Console.WriteLine(GetCenteredText("                           └─  ╩╩  ─┘  ╩ ╩╚═╝═╩╝╩╚═╝╩ ╩                            "));
                                                                                                                             
            Console.WriteLine(GetCenteredText("                           ┌─  ╦╦╦  ─┐  ╦ ╦╔═╗╦═╗╔╦╗                               "));
            Console.WriteLine(GetCenteredText("                           │   ║║║   │  ╠═╣╠═╣╠╦╝ ║║                               "));
            Console.WriteLine(GetCenteredText("                           └─  ╩╩╩  ─┘  ╩ ╩╩ ╩╩╚══╩╝                               "));
            Console.WriteLine(GetCenteredText(" "));
            Console.ResetColor();

            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(intercept: true); // No echo, immediate response

                if (char.IsDigit(key.KeyChar))
                {
                    int choice = key.KeyChar - '0'; // Convert char to int (e.g., '1' → 1)
                    if (choice >= 1 && choice <= 4)
                    {
                        Console.Clear(); // Move to the next line after selection
                        return choice;
                    }
                }

                // Optional: Play a "beep" sound for invalid input
                Console.Beep();
            }
        }

      
        public bool AskPlayAgain()
        {
            Console.WriteLine("Would you like to play again? (Y/N): ");
            char choice = Console.ReadKey().KeyChar;
            Console.WriteLine();
            return choice == 'Y' || choice == 'y';
        }
    }
}