﻿using System;

namespace HangmanGame
{
    public class Drawing
    {
        public static void Draw(int numGuesses)
        {
            switch (numGuesses)
            {
                case 1:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                                          ___________.._______                    ");
                    Console.WriteLine("                                         | .__________))______|                   ");
                    Console.WriteLine("                                         | | / /                                  ");
                    Console.WriteLine("                                         | |/ /                                   ");
                    Console.WriteLine("                                         | | /        .- ''.                      ");
                    Console.WriteLine("                                         | |/        / _   \\                     ");
                    Console.WriteLine("                                         | |         ||  `/,|                     ");
                    Console.WriteLine("                                         | |          \\`_.'                      ");
                    Console.WriteLine("                                         | |         .-`--'.                      ");
                    Console.WriteLine("                                         | |        / Y. .Y\\                     ");
                    Console.WriteLine("                                         | |       // |   | \\                    ");
                    Console.WriteLine("                                         | |      //  | . |  \\                   ");
                    Console.WriteLine("                                         | |     ')   |   |   (`                  ");
                    Console.WriteLine("                                         | |          || '|                       ");
                    Console.WriteLine("                                         | |          || ||                       ");
                    Console.WriteLine("                                         | |          || ||                       ");
                    Console.WriteLine("                                         | |         / | | \\                     ");
                    Console.WriteLine("                                         | |---------`-' `-'----------            ");
                    Console.WriteLine("                                         | |==========================            ");
                    Console.WriteLine("                                         | |_________________________             ");
                    break;
                case 2:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                                           ___________.._______                    ");
                    Console.WriteLine("                                          | .__________))______|                   ");
                    Console.WriteLine("                                          | | / /      ||                          ");
                    Console.WriteLine("                                          | |/ /                                   ");
                    Console.WriteLine("                                          | | /        .- ''.                      ");
                    Console.WriteLine("                                          | |/        / _   \\                     ");
                    Console.WriteLine("                                          | |         ||  `/,|                     ");
                    Console.WriteLine("                                          | |          \\`_.'                      ");
                    Console.WriteLine("                                          | |         .-`--'.                      ");
                    Console.WriteLine("                                          | |        / Y. .Y\\                     ");
                    Console.WriteLine("                                          | |       // |   | \\                    ");
                    Console.WriteLine("                                          | |      //  | . |  \\                   ");
                    Console.WriteLine("                                          | |     ')   |   |   (`                  ");
                    Console.WriteLine("                                          | |          || '|                       ");
                    Console.WriteLine("                                          | |          || ||                       ");
                    Console.WriteLine("                                          | |          || ||                       ");
                    Console.WriteLine("                                          | |         / | | \\                     ");
                    Console.WriteLine("                                          | |---------`-' `-'----------            ");
                    Console.WriteLine("                                          | |==========================            ");
                    Console.WriteLine("                                          | |_________________________             ");
                    break;
                case 3:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                                           ___________.._______                    ");
                    Console.WriteLine("                                          | .__________))______|                   ");
                    Console.WriteLine("                                          | | / /      ||                          ");
                    Console.WriteLine("                                          | |/ /       ||                          ");
                    Console.WriteLine("                                          | | /        .- ''.                      ");
                    Console.WriteLine("                                          | |/        / _   \\                     ");
                    Console.WriteLine("                                          | |         ||  `/,|                     ");
                    Console.WriteLine("                                          | |          \\`_.'                      ");
                    Console.WriteLine("                                          | |         .-`--'.                      ");
                    Console.WriteLine("                                          | |        / Y. .Y\\                     ");
                    Console.WriteLine("                                          | |       // |   | \\                    ");
                    Console.WriteLine("                                          | |      //  | . |  \\                   ");
                    Console.WriteLine("                                          | |     ')   |   |   (`                  ");
                    Console.WriteLine("                                          | |          || '|                       ");
                    Console.WriteLine("                                          | |          || ||                       ");
                    Console.WriteLine("                                          | |          || ||                       ");
                    Console.WriteLine("                                          | |         / | | \\                     ");
                    Console.WriteLine("                                          | |---------`-' `-'----------            ");
                    Console.WriteLine("                                          | |==========================            ");
                    Console.WriteLine("                                          | |_________________________             ");
                    break;
                case 4:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                                           ___________.._______                    ");
                    Console.WriteLine("                                          | .__________))______|                   ");
                    Console.WriteLine("                                          | | / /      ||                          ");
                    Console.WriteLine("                                          | |/ /       ||                          ");
                    Console.WriteLine("                                          | | /        |.- ''.                    ");
                    Console.WriteLine("                                          | |/         / _   \\                    ");
                    Console.WriteLine("                                          | |          ||  `/,|                    ");
                    Console.WriteLine("                                          | |          \\`_.'                      ");
                    Console.WriteLine("                                          | |         .-`--'.                      ");
                    Console.WriteLine("                                          | |        / Y. .Y\\                     ");
                    Console.WriteLine("                                          | |       // |   | \\                    ");
                    Console.WriteLine("                                          | |      //  | . |  \\                   ");
                    Console.WriteLine("                                          | |     ')   |   |   (`                  ");
                    Console.WriteLine("                                          | |          || '|                       ");
                    Console.WriteLine("                                          | |          || ||                       ");
                    Console.WriteLine("                                          | |          || ||                       ");
                    Console.WriteLine("                                          | |         / | | \\                     ");
                    Console.WriteLine("                                          | |---------`-' `-'----------            ");
                    Console.WriteLine("                                          | |==========================            ");
                    Console.WriteLine("                                          | |_________________________             ");
                    break;
                case 5:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                                            ___________.._______                    ");
                    Console.WriteLine("                                           | .__________))______|                   ");
                    Console.WriteLine("                                           | | / /      ||                          ");
                    Console.WriteLine("                                           | |/ /       ||                          ");
                    Console.WriteLine("                                           | | /        |.- ''.                    ");
                    Console.WriteLine("                                           | |/         |/ _   \\                   ");
                    Console.WriteLine("                                           | |          ||  `/,|                    ");
                    Console.WriteLine("                                           | |          (\\`_.'                     ");
                    Console.WriteLine("                                           | |         .-`--'.                      ");
                    Console.WriteLine("                                           | |        / Y. .Y\\                     ");
                    Console.WriteLine("                                           | |       // |   | \\                    ");
                    Console.WriteLine("                                           | |      //  | . |  \\                   ");
                    Console.WriteLine("                                           | |     ')   |   |   (`                  ");
                    Console.WriteLine("                                           | |          || '|                       ");
                    Console.WriteLine("                                           | |          || ||                       ");
                    Console.WriteLine("                                           | |          || ||                       ");
                    Console.WriteLine("                                           | |         / | | \\                     ");
                    Console.WriteLine("                                           | |---------`-' `-'----------            ");
                    Console.WriteLine("                                           | |==========================            ");
                    Console.WriteLine("                                           | |_________________________             ");
                    break;

                case 6:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("                                             ___________.._______                    ");
                    Console.WriteLine("                                            | .__________))______|                   ");
                    Console.WriteLine("                                            | | / /      ||                          ");
                    Console.WriteLine("                                            | |/ /       ||                          ");
                    Console.WriteLine("                                            | | /        | .- ''.                    ");
                    Console.WriteLine("                                            | |/         |/ _   \\                   ");
                    Console.WriteLine("                                            | |          ||  `/,|                    ");
                    Console.WriteLine("                                            | |          (\\`_.'                     ");
                    Console.WriteLine("                                            | |         .-`--'.                      ");
                    Console.WriteLine("                                            | |        / Y. .Y\\                     ");
                    Console.WriteLine("                                            | |       // |   | \\                    ");
                    Console.WriteLine("                                            | |      //  | . |  \\                   ");
                    Console.WriteLine("                                            | |     ')   |   |   (`                  ");
                    Console.WriteLine("                                            | |          || '|                       ");
                    Console.WriteLine("                                            | |          || ||                       ");
                    Console.WriteLine("                                            | |          || ||                       ");
                    Console.WriteLine("                                            | |________|`-' `-' |_______             ");
                    Console.WriteLine("                                            | |_________\\       \\_____             ");
                    Console.WriteLine("                                            | |__________\\       \\_____            ");
                    Console.ResetColor();                                   
                    Console.WriteLine();                                                                                            
                    Console.WriteLine("                                            ╔═╗╔═╗╔╦╗╔═╗  ╔═╗╦  ╦╔═╗╦═╗             "); 
                    Console.WriteLine("                                            ║ ╦╠═╣║║║║╣   ║ ║╚╗╔╝║╣ ╠╦╝             ");
                    Console.WriteLine("                                            ╚═╝╩ ╩╩ ╩╚═╝  ╚═╝ ╚╝ ╚═╝╩╚═             ");
                    break;
            }
        }
    }
}

  