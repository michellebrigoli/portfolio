﻿using System;
using System.Linq;

namespace HangmanGame
{
    public class MultiPlayer
    {
        private readonly GameModel _model;
        private readonly GameView _view;
        private readonly Drawing _drawing;
        private int player1Score = 0;
        private int player2Score = 0;
        private string player1Name;
        private string player2Name;
        private int roundsPlayed = 0;
        private const int RoundsToWin = 10;

        public static void PrintWriteCentered(string text)
        {
            int windowWidth = Console.WindowWidth;
            int centeredPosition = (windowWidth - text.Length) / 2;
            Console.SetCursorPosition(Math.Max(centeredPosition, 0), Console.CursorTop);
            Console.Write(text);
        }

        private void PrintCentered(string text, bool newLine = true)
        {
            int consoleWidth = Console.WindowWidth;
            int spaces = (consoleWidth - text.Length) / 2;
            if (newLine)
                Console.WriteLine(new string(' ', spaces) + text);
            else
                Console.Write(new string(' ', spaces) + text);
        }
        public MultiPlayer(GameModel model, GameView view)
        {
            _model = model;
            _view = view;
            _drawing = new Drawing();
        }

        public void Play()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Magenta;
            PrintCentered("╔────────────────────────────────────────────╗  ");
            PrintCentered("│░█▄█░█░█░█░░░▀█▀░▀█▀░█▀█░█░░░█▀█░█░█░█▀▀░█▀▄│  ");
            PrintCentered("│░█░█░█░█░█░░░░█░░░█░░█▀▀░█░░░█▀█░░█░░█▀▀░█▀▄│  ");
            PrintCentered("│░▀░▀░▀▀▀░▀▀▀░░▀░░▀▀▀░▀░░░▀▀▀░▀░▀░░▀░░▀▀▀░▀░▀│  ");
            PrintCentered("╚────────────────────────────────────────────╝  ");
            Console.ResetColor();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            PrintCentered("WELCOME TO HANGMAN: THE FINAL GUESS!");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine();
            PrintCentered("Player 1, enter your name: ", false);
            player1Name = Console.ReadLine();
            Console.WriteLine();
            PrintCentered("Player 2, enter your name: ", false);
            player2Name = Console.ReadLine();

            bool tournamentComplete = false;
            string currentWordmaster = player1Name;
            string currentChallenger = player2Name;

            while (!tournamentComplete)
            {
                Console.Clear();
                DrawScoreBox();

                PlayRound(currentWordmaster, currentChallenger);
                roundsPlayed++;

                string temp = currentWordmaster;
                currentWordmaster = currentChallenger;
                currentChallenger = temp;

                if (roundsPlayed >= RoundsToWin)
                {
                    tournamentComplete = true;
                    Console.Clear();
                    DrawScoreBox();
                    AnnounceWinner();
                }
                else
                {
                    PrintCentered($"\nRound {roundsPlayed + 1} of {RoundsToWin}. Press any key to continue...");
                    Console.ReadKey();
                }
            }
        }

        private void DrawScoreBox()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            PrintCentered("╔────────────────────────────────────────────╗  ");
            PrintCentered("│░█▄█░█░█░█░░░▀█▀░▀█▀░█▀█░█░░░█▀█░█░█░█▀▀░█▀▄│  ");
            PrintCentered("│░█░█░█░█░█░░░░█░░░█░░█▀▀░█░░░█▀█░░█░░█▀▀░█▀▄│  ");
            PrintCentered("│░▀░▀░▀▀▀░▀▀▀░░▀░░▀▀▀░▀░░░▀▀▀░▀░▀░░▀░░▀▀▀░▀░▀│  ");
            PrintCentered("╚────────────────────────────────────────────╝  ");
            Console.ResetColor();
            Console.WriteLine();
            string scoreLine = $"║ {player1Name}: {player1Score} │ {player2Name}: {player2Score} ║";
            int boxWidth = scoreLine.Length;

            PrintCentered("╔" + new string('═', boxWidth - 2) + "╗");
            PrintCentered(scoreLine);
            PrintCentered("╚" + new string('═', boxWidth - 2) + "╝");
        }

        private void AnnounceWinner()
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.Clear();
            PrintCentered("\n══════════════════════════════════════");
            PrintCentered("         GAME RESULTS          ");
            PrintCentered("══════════════════════════════════════\n");

            DrawScoreBox();
            Console.WriteLine();

            if (player1Score > player2Score)
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                PrintCentered("╔════════════════════════════════════════════════════╗");
                PrintCentered("║           By Order of SIR DERIT                    ║");
                PrintCentered("║                                                    ║");
                PrintCentered("║  After showing amazing skill with words,           ║");
                PrintCentered($"║  We proudly declare {player1Name.ToUpper(),-18}     ║");
                PrintCentered("║  The new:                                          ║");
                PrintCentered("║             WORD MASTER CHAMPION                   ║");
                PrintCentered("║                                                    ║");
                PrintCentered("╚════════════════════════════════════════════════════╝");
                Console.ResetColor();

            }
            else if (player2Score > player1Score)
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                PrintCentered(" ╔════════════════════════════════════════════════════╗");
                PrintCentered(" ║           By Order of SIR DERIT                    ║");
                PrintCentered(" ║                                                    ║");
                PrintCentered(" ║  After showing amazing skill with words,           ║");
                PrintCentered($"║  We proudly declare {player2Name.ToUpper(),-18}    ║");
                PrintCentered(" ║  The new:                                          ║");
                PrintCentered(" ║             WORD MASTER CHAMPION                   ║");
                PrintCentered(" ║                                                    ║");
                PrintCentered(" ╚════════════════════════════════════════════════════╝");
                Console.ResetColor();
            }
            else
            {
                PrintCentered("══════════════════════════════════════");
                PrintCentered("       IT'S A TIE! EQUAL SKILLS       ");
                PrintCentered("══════════════════════════════════════");
            }


            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            PrintCentered("Press any key to exit...");
            Console.ResetColor();
            Console.ReadKey();
        }

        private void PlayRound(string wordmaster, string challenger)
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            PrintCentered($"{wordmaster}, you're the Wordmaster on this round!");
            Console.WriteLine();
            PrintCentered($"{challenger}, you're the Challenger!");
            Console.ResetColor();

            string wordToGuess = _view.GetWordToGuess(wordmaster).ToLower();
            int wordLength = wordToGuess.Length;
            int numGuesses = 0;
            int correctGuesses = 0;
            bool[] guessedLetters = new bool[26];
            bool gameWon = false;
            int hintsRemaining = 3;

            Console.Clear();
            DrawScoreBox();
            char[] hiddenWord = new char[wordLength];
            for (int i = 0; i < wordLength; i++)
            {
                hiddenWord[i] = '_';
            }

            while (numGuesses < GameModel.MAX_GUESSES && !gameWon)
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                PrintCentered("CURRENT WORD: " + new string(hiddenWord));
                Console.WriteLine($"Guesses left: {GameModel.MAX_GUESSES - numGuesses}");
                Console.WriteLine($"Hints left: {hintsRemaining}");
                Console.Write("Guessed letters: ");
                Console.ResetColor();
                for (int i = 0; i < 26; i++)
                {
                    if (guessedLetters[i]) Console.Write((char)(i + 'a') + ", ");
                }
                Console.WriteLine("\n(Press 0 for a hint)");

                ConsoleKeyInfo keyInfo = Console.ReadKey(true); // Read key without displaying it
                char inputChar = keyInfo.KeyChar;

                if (inputChar == '0')
                {
                    if (hintsRemaining > 0)
                    {
                        var unrevealedIndices = Enumerable.Range(0, wordLength)
                            .Where(i => hiddenWord[i] == '_')
                            .ToList();

                        if (unrevealedIndices.Count > 0)
                        {
                            Random rand = new Random();
                            int hintIndex = unrevealedIndices[rand.Next(unrevealedIndices.Count)];
                            hiddenWord[hintIndex] = wordToGuess[hintIndex];
                            correctGuesses++;
                            hintsRemaining--;
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Drawing.Draw(numGuesses);
                            Console.WriteLine($"\nHint: Revealed letter '{wordToGuess[hintIndex]}'");
                            Console.ResetColor();
                            

                            if (correctGuesses == wordLength)
                            {
                                gameWon = true;
                                Console.WriteLine($"\n{challenger} wins this round! The word was: {wordToGuess}");
                                if (challenger == player1Name)
                                    player1Score++;
                                else
                                    player2Score++;
                            }
                        }
                        else
                        {
                            Console.WriteLine("\nNo letters left to reveal!");
                        }
                        continue;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("\nNo hints remaining!");
                        continue;
                    }
                }

                if (!char.IsLetter(inputChar))
                {
                    Console.Clear();
                    Console.WriteLine("\nInvalid input. Please enter a letter or 0 for hint.");
                    continue;
                }

                char letter = char.ToLower(inputChar);

                if (guessedLetters[letter - 'a'])
                {
                    Console.Clear();
                    Drawing.Draw(numGuesses);
                    Console.WriteLine("\nYou already guessed that letter.");
                    continue;
                }
                guessedLetters[letter - 'a'] = true;

                bool correctGuess = false;
                for (int i = 0; i < wordLength; i++)
                {
                    if (wordToGuess[i] == letter)
                    {
                        hiddenWord[i] = letter;
                        correctGuess = true;
                        correctGuesses++;
                    }
                }

                if (correctGuess)
                {
                    Console.Clear();
                    DrawScoreBox();
                    Drawing.Draw(numGuesses);
                    Console.WriteLine("\nGood guess!");
                    if (correctGuesses == wordLength)
                    {
                        gameWon = true;
                        PrintCentered($"\n{challenger} wins this round! The word was: {wordToGuess}");
                        if (challenger == player1Name)
                            player1Score++;
                        else
                            player2Score++;
                    }
                }
                else
                {
                    numGuesses++;
                    Console.Clear();
                    DrawScoreBox();
                    Drawing.Draw(numGuesses);
                    Console.WriteLine("\nWrong guess!");
                }
            }

            if (!gameWon)
            {
                PrintCentered($"\n{wordmaster} wins this round! The word was: {wordToGuess}");
                if (wordmaster == player1Name)
                    player1Score++;
                else
                    player2Score++;
            }
        }
    }
}