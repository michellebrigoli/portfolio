﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace HangmanGame
{
    public class SinglePlayer
    {
        private readonly GameModel _model;
        private readonly GameView _view;
        private readonly Drawing _drawing;
        private int _totalPoints;
        private int _totalGamesPlayed;
        private int _totalGamesWon;
        private bool _resurrectionUsed;

        public SinglePlayer(GameModel model, GameView view)
        {
            _model = model;
            _view = view;
            _drawing = new Drawing();
            _totalPoints = 0;
            _totalGamesPlayed = 0;
            _totalGamesWon = 0;
        }
        public void PrintCentered(string text)
        {
            int windowWidth = Console.WindowWidth;
            int centeredPosition = (windowWidth - text.Length) / 2;
            Console.SetCursorPosition(Math.Max(centeredPosition, 0), Console.CursorTop);
            Console.WriteLine(text);
        }

        public void Play()
        {
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("                                    ╔──────────────────────────────────────────────────╗   ");
            Console.WriteLine("                                    │░█▀▀░▀█▀░█▀█░█▀▀░█░░░█▀▀░░░█▀█░█░░░█▀█░█░█░█▀▀░█▀▄│   ");
            Console.WriteLine("                                    │░▀▀█░░█░░█░█░█░█░█░░░█▀▀░░░█▀▀░█░░░█▀█░░█░░█▀▀░█▀▄│   ");
            Console.WriteLine("                                    │░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀▀▀░░░▀░░░▀▀▀░▀░▀░░▀░░▀▀▀░▀░▀│   ");
            Console.WriteLine("                                    ╚──────────────────────────────────────────────────╝   ");
            Console.ResetColor();
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            string playerName = _view.GetPlayerName(GetCenteredText("ENTER YOUR NAME: "));
            Console.Clear();
            Console.ResetColor();

            int difficultyChoice = _view.GetDifficultyChoice();
            string difficulty = difficultyChoice == 1 ? "Easy" : (difficultyChoice == 2 ? "Medium" : "Hard");
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("                                    ╔──────────────────────────────────────────────────╗   ");
            Console.WriteLine("                                    │░█▀▀░▀█▀░█▀█░█▀▀░█░░░█▀▀░░░█▀█░█░░░█▀█░█░█░█▀▀░█▀▄│   ");
            Console.WriteLine("                                    │░▀▀█░░█░░█░█░█░█░█░░░█▀▀░░░█▀▀░█░░░█▀█░░█░░█▀▀░█▀▄│   ");
            Console.WriteLine("                                    │░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀▀▀░░░▀░░░▀▀▀░▀░▀░░▀░░▀▀▀░▀░▀│   ");
            Console.WriteLine("                                    ╚──────────────────────────────────────────────────╝   ");
            Console.WriteLine("\n");
            Console.WriteLine(GetCenteredText($"WELCOME, {playerName.ToUpper()}!"));
            Console.WriteLine("\n");
            Console.WriteLine(GetCenteredText("Prepare to challenge your mind and test your luck."));
            Console.WriteLine(GetCenteredText("Guess wisely, for each letter brings you closer to victory... or defeat!"));
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine(GetCenteredText("PRESS ANY KEY TO BEGIN..."));
            Console.ResetColor();
            Console.ReadKey();
            Console.Clear();
            int wordPoints = _model.DifficultyPoints[difficulty];
            int hintsAvailable = difficultyChoice == 1 ? 2 : (difficultyChoice == 2 ? 3 : 5);

            bool playing = true;
            while (playing)
            {
                _totalGamesPlayed++;
                PlayRound(playerName, difficulty, wordPoints, hintsAvailable);
                DisplayScoreSummary(playerName);
                playing = _view.AskPlayAgain();
            }
        }

        private void DisplayScoreSummary(string playerName)
        {
            Console.Clear();
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            PrintCentered("   ╔════════════════════════════════════════════╗");
            PrintCentered("   ║               SCORE SUMMARY                ║");
            PrintCentered("  ╠════════════════════════════════════════════╣");
            PrintCentered($" ║ Player: {playerName,-32}    ║");
            PrintCentered($" ║ Total Points: {_totalPoints,-26}    ║");
            PrintCentered($"║ Games Played: {_totalGamesPlayed,-26}    ║");
            PrintCentered($"║ Games Won: {_totalGamesWon,-28}     ║");
            PrintCentered($"║ Win Rate: {(_totalGamesPlayed > 0 ? (_totalGamesWon * 100 / _totalGamesPlayed) : 0)}%{"",-27}  ║");
            Console.ResetColor();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }

        private string GetCenteredText(string text)
        {
            int windowWidth = Console.WindowWidth;
            int padding = (windowWidth - text.Length) / 2;
            return new string(' ', padding) + text;
        }

        private void PlayRound(string playerName, string difficulty, int wordPoints, int hintsAvailable)
        {
            Random random = new Random();
            string wordToGuess = _model.WordCategories[difficulty][random.Next(_model.WordCategories[difficulty].Length)];
            int wordLength = wordToGuess.Length;
            int numGuesses = 0;
            int correctGuesses = 0;
            List<char> guessedLetters = new List<char>();
            bool gameWon = false;

            char[] hiddenWord = new char[wordLength];
            for (int i = 0; i < wordLength; i++)
            {
                hiddenWord[i] = '_';
            }

            while (numGuesses < GameModel.MAX_GUESSES && !gameWon)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Magenta;
                PrintCentered("\n");
                PrintCentered("            ╔──────────────────────────────────────────────────╗   ");
                PrintCentered("            │░█▀▀░▀█▀░█▀█░█▀▀░█░░░█▀▀░░░█▀█░█░░░█▀█░█░█░█▀▀░█▀▄│   ");
                PrintCentered("            │░▀▀█░░█░░█░█░█░█░█░░░█▀▀░░░█▀▀░█░░░█▀█░░█░░█▀▀░█▀▄│   ");
                PrintCentered("            │░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀▀▀░░░▀░░░▀▀▀░▀░▀░░▀░░▀▀▀░▀░▀│   ");
                PrintCentered("            ╚──────────────────────────────────────────────────╝   ");
                Console.ResetColor();
                Console.WriteLine();

                // Show game status - using original drawing code
                Drawing.Draw(numGuesses);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Wrong Guesses {numGuesses}");
                Console.ResetColor();
                Console.WriteLine();

                // Display game information
                Console.WriteLine($"Current word: {new string(hiddenWord)}");
                Console.WriteLine($"Guesses left: {GameModel.MAX_GUESSES - numGuesses}");
                Console.WriteLine($"Hints available: {hintsAvailable}");
                Console.WriteLine("Guessed letters: " + string.Join(", ", guessedLetters));
                Console.WriteLine();

                Console.Write("Guess a letter (or press '0' for a hint): ");
                char letter = Console.ReadKey().KeyChar;
                Console.WriteLine();

                // Handle hint request
                if (letter == '0')
                {
                    if (hintsAvailable > 0)
                    {
                        var unrevealedIndices = Enumerable.Range(0, wordLength)
                            .Where(i => hiddenWord[i] == '_')
                            .ToList();

                        if (unrevealedIndices.Count > 0)
                        {
                            Random rand = new Random();
                            int hintIndex = unrevealedIndices[rand.Next(unrevealedIndices.Count)];
                            hiddenWord[hintIndex] = wordToGuess[hintIndex];
                            correctGuesses++;
                            hintsAvailable--;
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine($"\nHint: Revealed letter '{wordToGuess[hintIndex]}'");
                            Console.ResetColor();

                            if (correctGuesses == wordLength)
                            {
                                gameWon = true;
                            }
                        }
                        else
                        {
                            Console.WriteLine("\nNo letters left to reveal!");
                        }
                        continue;
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("\nNo hints remaining!");
                        continue;
                    }
                }

                if (!char.IsLetter(letter))
                {
                    Console.WriteLine("Please enter a valid letter.");
                    continue;
                }

                letter = char.ToLower(letter);
                if (guessedLetters.Contains(letter))
                {
                    Console.WriteLine("You already guessed that letter.");
                    continue;
                }

                guessedLetters.Add(letter);
                bool correctGuess = false;

                for (int i = 0; i < wordLength; i++)
                {
                    if (wordToGuess[i] == letter)
                    {
                        hiddenWord[i] = letter;
                        correctGuess = true;
                        correctGuesses++;
                    }
                }

                if (!correctGuess)
                {
                    numGuesses++;
                    Console.Clear();
                    Drawing.Draw(numGuesses);
                    Console.ForegroundColor = ConsoleColor.Red;
                  /*  Console.WriteLine($"Wrong Guesses {numGuesses}"); */
                    Console.WriteLine("\nWrong guess!");
                    Console.ResetColor();
                }
                else
                {
                    Console.Clear();
                    Drawing.Draw(numGuesses);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Wrong Guesses {numGuesses}");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nGood guess!");
                    Console.ResetColor();
                }

                if (correctGuesses == wordLength)
                {
                    gameWon = true;
                }
            }

            Console.Clear();
            if (gameWon)
            {
                _totalPoints += wordPoints;
                _totalGamesWon++;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\nCongratulations, {playerName}! You guessed the word: {wordToGuess}");
                Console.WriteLine($"You earned {wordPoints} points! (Total: {_totalPoints})");
                Console.ResetColor();
            }
            else
            {
                Drawing.Draw(numGuesses);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\nGame Over! The word was: {wordToGuess}");
                Console.ResetColor();
            }
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}