﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_Group1
{
    class Banner
    {
        public static void bannerMainScreen()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("");
            Console.WriteLine("\t╔═══════════════════════════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                ██████╗   ██╗        █████╗   ██╗   ██╗                                ║");
            Console.WriteLine("\t║                                ██╔══██╗  ██║       ██╔══██╗  ╚██╗ ██╔╝                                ║");
            Console.WriteLine("\t║                                ██████╔╝  ██║       ███████║   ╚████╔╝                                 ║");
            Console.WriteLine("\t║                                ██╔═══╝   ██║       ██╔══██║    ╚██╔╝                                  ║");
            Console.WriteLine("\t║                                ██║       ███████╗  ██║  ██║     ██║                                   ║");
            Console.WriteLine("\t║                                ╚═╝       ╚══════╝  ╚═╝  ╚═╝     ╚═╝                                   ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║             ████████╗ ██╗  ██████╗ ████████╗  █████╗   ██████╗ ████████╗  ██████╗  ███████╗           ║");
            Console.WriteLine("\t║             ╚══██╔══╝ ██║ ██╔════╝ ╚══██╔══╝ ██╔══██╗ ██╔════╝ ╚══██╔══╝ ██╔═══██╗ ██╔════╝           ║");
            Console.WriteLine("\t║                ██║    ██║ ██║         ██║    ███████║ ██║         ██║    ██║   ██║ █████╗             ║");
            Console.WriteLine("\t║                ██║    ██║ ██║         ██║    ██╔══██║ ██║         ██║    ██║   ██║ ██╔══╝             ║");
            Console.WriteLine("\t║                ██║    ██║ ╚██████╗    ██║    ██║  ██║ ╚██████╗    ██║    ╚██████╔╝ ███████╗           ║");
            Console.WriteLine("\t║                ╚═╝    ╚═╝  ╚═════╝    ╚═╝    ╚═╝  ╚═╝  ╚═════╝    ╚═╝     ╚═════╝  ╚══════╝           ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t║                                                                                                       ║");
            Console.WriteLine("\t╚═══════════════════════════════════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("                                       Press any key to proceed to the main menu.");
            Console.ResetColor();
        }

        public static void bannerGameon()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t ██████╗  █████╗ ███╗   ███╗███████╗     ██████╗ ███╗   ██╗");
            Console.WriteLine("\t\t\t\t██╔════╝ ██╔══██╗████╗ ████║██╔════╝    ██╔═══██╗████╗  ██║");
            Console.WriteLine("\t\t\t\t██║  ███╗███████║██╔████╔██║█████╗      ██║   ██║██╔██╗ ██║");
            Console.WriteLine("\t\t\t\t██║   ██║██╔══██║██║╚██╔╝██║██╔══╝      ██║   ██║██║╚██╗██║");
            Console.WriteLine("\t\t\t\t╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗    ╚██████╔╝██║ ╚████║");
            Console.WriteLine("\t\t\t\t ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝     ╚═════╝ ╚═╝  ╚═══╝");
            Console.ResetColor();
        }
        public static void bannerMainMenu()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\t╔══════════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                                                                                      ║");
            Console.WriteLine("\t\t║      ███╗   ███╗ █████╗ ██╗███╗   ██╗    ███╗   ███╗███████╗███╗   ██╗██╗   ██╗      ║ ");
            Console.WriteLine("\t\t║      ████╗ ████║██╔══██╗██║████╗  ██║    ████╗ ████║██╔════╝████╗  ██║██║   ██║      ║ ");
            Console.WriteLine("\t\t║      ██╔████╔██║███████║██║██╔██╗ ██║    ██╔████╔██║█████╗  ██╔██╗ ██║██║   ██║      ║ ");
            Console.WriteLine("\t\t║      ██║╚██╔╝██║██╔══██║██║██║╚██╗██║    ██║╚██╔╝██║██╔══╝  ██║╚██╗██║██║   ██║      ║ ");
            Console.WriteLine("\t\t║      ██║ ╚═╝ ██║██║  ██║██║██║ ╚████║    ██║ ╚═╝ ██║███████╗██║ ╚████║╚██████╔╝      ║ ");
            Console.WriteLine("\t\t║      ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝    ╚═╝     ╚═╝╚══════╝╚═╝  ╚═══╝ ╚═════╝       ║ ");
            Console.WriteLine("\t\t║                                                                                      ║");
            Console.WriteLine("\t\t╚══════════════════════════════════════════════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.WriteLine();
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\t\t                                 [1] -> Play Game          \n");
            Console.WriteLine("\t\t                                 [2] -> How to Play        \n");
            Console.WriteLine("\t\t                                 [3] -> Developers         \n");
            Console.WriteLine("\t\t                                 [4] -> Main Screen        \n");
            Console.WriteLine("\t\t                                 [5] -> Exit               \n");
            Console.WriteLine("");
            Console.Write("\t                                         Choose an option: ");
            Console.ResetColor();

        }

        public static void bannerPlayGame()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine();    
            Console.WriteLine();    
            Console.WriteLine("\t╔═══════════════════════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("\t║                                                                                                   ║");
            Console.WriteLine("\t║         ██████╗ ██╗      █████╗ ██╗   ██╗     ██████╗  █████╗ ███╗   ███╗███████╗    ██╗          ║");
            Console.WriteLine("\t║         ██╔══██╗██║     ██╔══██╗╚██╗ ██╔╝    ██╔════╝ ██╔══██╗████╗ ████║██╔════╝    ██║          ║");
            Console.WriteLine("\t║         ██████╔╝██║     ███████║ ╚████╔╝     ██║  ███╗███████║██╔████╔██║█████╗      ██║          ║");
            Console.WriteLine("\t║         ██╔═══╝ ██║     ██╔══██║  ╚██╔╝      ██║   ██║██╔══██║██║╚██╔╝██║██╔══╝      ╚═╝          ║");
            Console.WriteLine("\t║         ██║     ███████╗██║  ██║   ██║       ╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗    ██╗          ║");
            Console.WriteLine("\t║         ╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝        ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝    ╚═╝          ║");
            Console.WriteLine("\t║                                                                                                   ║");
            Console.WriteLine("\t╚═══════════════════════════════════════════════════════════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.ResetColor();
        }
        public static void bannerHowtoplay()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine();
            Console.WriteLine("\t ╔══════════════════════════════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("\t ║                                                                                                          ║");
            Console.WriteLine("\t ║     ██╗  ██╗ ██████╗ ██╗    ██╗    ████████╗ ██████╗     ██████╗ ██╗      █████╗ ██╗   ██╗  ██████╗      ║");
            Console.WriteLine("\t ║     ██║  ██║██╔═══██╗██║    ██║    ╚══██╔══╝██╔═══██╗    ██╔══██╗██║     ██╔══██╗╚██╗ ██╔╝  ╚════██╗     ║");
            Console.WriteLine("\t ║     ███████║██║   ██║██║ █╗ ██║       ██║   ██║   ██║    ██████╔╝██║     ███████║ ╚████╔╝     ▄███╔╝     ║");
            Console.WriteLine("\t ║     ██╔══██║██║   ██║██║███╗██║       ██║   ██║   ██║    ██╔═══╝ ██║     ██╔══██║  ╚██╔╝      ▀▀══╝      ║");
            Console.WriteLine("\t ║     ██║  ██║╚██████╔╝╚███╔███╔╝       ██║   ╚██████╔╝    ██║     ███████╗██║  ██║   ██║       ██╗        ║");
            Console.WriteLine("\t ║     ╚═╝  ╚═╝ ╚═════╝  ╚══╝╚══╝        ╚═╝    ╚═════╝     ╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝       ╚═╝        ║");
            Console.WriteLine("\t ║                                                                                                          ║");
            Console.WriteLine("\t ╚══════════════════════════════════════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine("\t ------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t [1] From the Main Menu, select option 1: \"Play Game\".");
            Console.WriteLine("\t [2] Choose your preferred Game Mode:");
            Console.WriteLine("\t     - \"Player vs Player\" (PvP) to play with a friend.");
            Console.WriteLine("\t     - \"Player vs Computer\" (PvComp) to play against the Computer.");
            Console.WriteLine("\t [3] If PvP is selected, enter both players' names.");
            Console.WriteLine("\t [4] If PvC is selected, enter your name and select the difficulty level.");
            Console.WriteLine("");
            Console.WriteLine("\t GAME RULES:");
            Console.WriteLine("\t ------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t - Players take turns placing 'X' or 'O' on the board.");
            Console.WriteLine("\t - The first player to align three symbols in a row wins.");
            Console.WriteLine("\t - Each game consists of 5 rounds.");
            Console.WriteLine("\t - The first player to win 3 rounds wins the match.");
            Console.WriteLine("\t - If the board is full and no one wins, the round resets until there is a winner.");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("\t\t\t\t\t Press any key to return to the main screen...");
            Console.ResetColor();

        }
        public static void bannerDevelopers()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\t\t ╔════════════════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t ║                                                                                            ║");
            Console.WriteLine("\t\t ║     ██████╗ ███████╗██╗   ██╗███████╗██╗      ██████╗ ██████╗ ███████╗██████╗ ███████╗     ║");
            Console.WriteLine("\t\t ║     ██╔══██╗██╔════╝██║   ██║██╔════╝██║     ██╔═══██╗██╔══██╗██╔════╝██╔══██╗██╔════╝     ║");
            Console.WriteLine("\t\t ║     ██║  ██║█████╗  ██║   ██║█████╗  ██║     ██║   ██║██████╔╝█████╗  ██████╔╝███████╗     ║");
            Console.WriteLine("\t\t ║     ██║  ██║██╔══╝  ╚██╗ ██╔╝██╔══╝  ██║     ██║   ██║██╔═══╝ ██╔══╝  ██╔══██╗╚════██║     ║");
            Console.WriteLine("\t\t ║     ██████╔╝███████╗ ╚████╔╝ ███████╗███████╗╚██████╔╝██║     ███████╗██║  ██║███████║     ║");
            Console.WriteLine("\t\t ║     ╚═════╝ ╚══════╝  ╚═══╝  ╚══════╝╚══════╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═╝╚══════╝     ║");
            Console.WriteLine("\t\t ║                                                                                            ║");
            Console.WriteLine("\t\t ╚════════════════════════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t| Name:     Al Vincent M. Fabrique                         |");
            Console.WriteLine("\t\t\t\t| Motto:    \"Life is short, but my patience is shorter.\"   |");
            Console.WriteLine("\t\t\t\t| Status:   Alive                                          |");
            Console.WriteLine("\t\t\t\t------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t| Name:     Michelle Brigoli                               |");
            Console.WriteLine("\t\t\t\t| Motto:    \"I believe I can fly.\"                         |");
            Console.WriteLine("\t\t\t\t| Status:   PUBG is life.                                  |");
            Console.WriteLine("\t\t\t\t------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t| Name:     Jacenfa Dayangco                               |");
            Console.WriteLine("\t\t\t\t| Motto:    \"To see is to Believe.\"                        |");
            Console.WriteLine("\t\t\t\t| Status:   Single-Double                                  |");
            Console.WriteLine("\t\t\t\t------------------------------------------------------------");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t\tPress any key to return to the main screen...");
            Console.ResetColor();
        }

        

    }
}
