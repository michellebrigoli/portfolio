﻿using System;
using System.Linq;

namespace TicTacToe_Group1
{
    class Board
    {
        private char[] board;
        private char currentPlayer;

        public Board()
        {
            ResetBoard();
        }

        public void DisplayBoards()
        {
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t        Guide Board:                 Game Board:");
            Console.WriteLine("\t\t\t\t    ╔═════╦═════╦═════╗          ╔═════╦═════╦═════╗");
            Console.WriteLine($"\t\t\t\t    ║  1  ║  2  ║  3  ║          ║  {GetCell(0)}  ║  {GetCell(1)}  ║  {GetCell(2)}  ║");
            Console.WriteLine("\t\t\t\t    ╠═════╬═════╬═════╣          ╠═════╬═════╬═════╣");
            Console.WriteLine($"\t\t\t\t    ║  4  ║  5  ║  6  ║          ║  {GetCell(3)}  ║  {GetCell(4)}  ║  {GetCell(5)}  ║");
            Console.WriteLine("\t\t\t\t    ╠═════╬═════╬═════╣          ╠═════╬═════╬═════╣");
            Console.WriteLine($"\t\t\t\t    ║  7  ║  8  ║  9  ║          ║  {GetCell(6)}  ║  {GetCell(7)}  ║  {GetCell(8)}  ║");
            Console.WriteLine("\t\t\t\t    ╚═════╩═════╩═════╝          ╚═════╩═════╩═════╝\n");
        }


        private string GetCell(int index)
        {
            if (board[index] == 'X')
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else if (board[index] == 'O')
            {
                Console.ForegroundColor = ConsoleColor.Blue;
            }
            else
            {
                Console.Write(" ");
            }
            Console.ResetColor();
            return board[index].ToString();
        }

        public bool MakeMove(int position)
        {
            if (position < 1 || position > 9)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\t\t\t\t     Invalid move! Position must be between 1 and 9.");
                Console.ResetColor();
                return false;
            }

            if (board[position - 1] != ' ')
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine();
                Console.WriteLine("\t\t\t\t     Invalid move! The spot is already taken.");
                Console.ResetColor();
                return false;
            }

            board[position - 1] = currentPlayer;
            return true;
        }

        public bool CheckWin()
        {
            int[,] winConditions = new int[,]
            {
                { 0, 1, 2 }, { 3, 4, 5 }, { 6, 7, 8 },
                { 0, 3, 6 }, { 1, 4, 7 }, { 2, 5, 8 },
                { 0, 4, 8 }, { 2, 4, 6 }
            };

              for (int i = 0; i < winConditions.GetLength(0); i++)
            {
                int a = winConditions[i, 0];
                int b = winConditions[i, 1];
                int c = winConditions[i, 2];

                if (board[a] == currentPlayer && board[b] == currentPlayer && board[c] == currentPlayer)
                {
                    return true;
                }
            }
            return false;
        }


        public bool IsDraw() => !board.Contains(' ');

        public void SwitchPlayer()
        {
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }

        public void ResetBoard()
        {
            board = Enumerable.Repeat(' ', 9).ToArray();
            currentPlayer = 'X';
        }

        public char GetCurrentPlayer() => currentPlayer;

        public char[] GetBoard() => board;
    }
}
