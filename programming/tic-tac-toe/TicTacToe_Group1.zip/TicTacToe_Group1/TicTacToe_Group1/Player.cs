﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe_Group1
{
    class Player
    {
        public string Name { get; private set; }
        public char Symbol { get; private set; }
        public int Score { get; private set; }

        public Player(string name, char symbol)
        {
            Name = name;
            Symbol = symbol;
            Score = 0;
        }

        public void AddWin()
        {
            Score++;
        }

        public void ResetScore()
        {
            Score = 0;
        }
    }

}
