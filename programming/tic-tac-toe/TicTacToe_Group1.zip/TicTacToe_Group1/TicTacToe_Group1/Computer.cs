﻿using System;

namespace TicTacToe_Group1
{
    class Computer
    {
        private Random random;

        public Computer()
        {
            random = new Random();
        }

        public int GetEasyMove(char[] board)
        {
            int move;
            do
            {
                move = random.Next(1, 10);
            } while (board[move - 1] == 'X' || board[move - 1] == 'O');

            return move;
        }

        public int GetMediumMove(char[] board, char aiMarker, char playerMarker)
        {

            for (int i = 0; i < 9; i++)
            {
                if (board[i] != 'X' && board[i] != 'O')
                {
                    char[] tempBoard = (char[])board.Clone();
                    tempBoard[i] = aiMarker;
                    if (CheckWin(tempBoard, aiMarker))
                        return i + 1;
                }
            }


            for (int i = 0; i < 9; i++)
            {
                if (board[i] != 'X' && board[i] != 'O')
                {
                    char[] tempBoard = (char[])board.Clone();
                    tempBoard[i] = playerMarker;
                    if (CheckWin(tempBoard, playerMarker))
                        return i + 1;
                }
            }


            return GetEasyMove(board);
        }

        public int GetImpossibleMove(char[] board, char aiMarker, char playerMarker)
        {
            return Minimax(board, aiMarker, playerMarker, true).Item2;
        }

        private bool CheckWin(char[] board, char marker)
        {
            int[,] winConditions = new int[,]
            {
                { 0, 1, 2 }, { 3, 4, 5 }, { 6, 7, 8 },
                { 0, 3, 6 }, { 1, 4, 7 }, { 2, 5, 8 },
                { 0, 4, 8 }, { 2, 4, 6 }
            };

            for (int i = 0; i < winConditions.GetLength(0); i++)
            {
                if (board[winConditions[i, 0]] == marker &&
                    board[winConditions[i, 1]] == marker &&
                    board[winConditions[i, 2]] == marker)
                {
                    return true;
                }
            }

            return false;
        }

        private Tuple<int, int> Minimax(char[] board, char aiMarker, char playerMarker, bool isMaximizing)
        {

            if (CheckWin(board, aiMarker)) return Tuple.Create(10, -1);
            if (CheckWin(board, playerMarker)) return Tuple.Create(-10, -1);
            if (!Array.Exists(board, spot => spot != 'X' && spot != 'O')) return Tuple.Create(0, -1);

            int bestScore = isMaximizing ? -1000 : 1000;
            int bestMove = -1;

            for (int i = 0; i < 9; i++)
            {
                if (board[i] != 'X' && board[i] != 'O')
                {
                    char[] tempBoard = (char[])board.Clone();
                    tempBoard[i] = isMaximizing ? aiMarker : playerMarker;

                    int score = Minimax(tempBoard, aiMarker, playerMarker, !isMaximizing).Item1;

                    if ((isMaximizing && score > bestScore) || (!isMaximizing && score < bestScore))
                    {
                        bestScore = score;
                        bestMove = i + 1;
                    }
                }
            }

            return Tuple.Create(bestScore, bestMove);
        }
    }
}
