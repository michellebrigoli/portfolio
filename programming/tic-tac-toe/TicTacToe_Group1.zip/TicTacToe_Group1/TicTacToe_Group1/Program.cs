﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;

namespace TicTacToe_Group1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool mainScreen = true;

            while (mainScreen)
            {
                Console.Clear();
                Banner.bannerMainScreen();
                Console.ReadKey();

                bool onMainMenu = true;
                while (onMainMenu)
                {
                    Console.Clear();
                    Banner.bannerMainMenu();
                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            StartGame();
                            break;
                        case "2":
                            Console.Clear();
                            Banner.bannerHowtoplay();
                            Console.ReadKey();
                            break;
                        case "3":
                            Console.Clear();
                            Banner.bannerDevelopers();
                            Console.ReadKey();
                            break;
                        case "4":
                            Console.WriteLine("\n\tReturning to the Main Screen...");
                            onMainMenu = false; 
                            break;
                        case "5":
                            mainScreen = false;
                            onMainMenu = false; 
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("\n\t\t\t\t      Invalid choice! Press any key to try again.");
                            Console.ResetColor();
                            Console.ReadKey();
                            break;
                    }
                }
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\t\t\t\t\t\t Thanks for playing!");
            Console.ResetColor();
        }


        static void StartGame()
        {
            while (true)
            {
                Console.Clear();

                bool gameMode = true;

                while (gameMode)
                {
                    Console.Clear();
                    Banner.bannerPlayGame();
                    PrintSelectionMode();

                    string mode = Console.ReadLine();

                    if (mode == "1")
                    {
                        string player1Name, player2Name;

                        while (true)
                        {
                            Console.Clear();
                            Banner.bannerPlayGame();
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("        ======================================== PLAYER VS PLAYER  =========================================");
                            Console.WriteLine();
                            Console.ResetColor();

                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("\n\t\t\t\t\t   Enter Player 1's name: ");
                            player1Name = Console.ReadLine();
                            Console.Write("\n\t\t\t\t\t   Enter Player 2's name: ");
                            player2Name = Console.ReadLine();
                            Console.ResetColor();

                            if (!string.IsNullOrWhiteSpace(player1Name) && player1Name.All(char.IsLetter) &&
                                !string.IsNullOrWhiteSpace(player2Name) && player2Name.All(char.IsLetter))
                            {
                                break;
                            }

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("\n\t\t\t\t      Invalid Names! Press any key to try again...");
                            Console.ResetColor();
                            Console.ReadKey();
                        }

                        Console.ResetColor();
                        Console.Clear();

                        PlayGame(player1Name, player2Name, false);
                        break;
                    }




                    else if (mode == "2")
                    {
                        string playerName;


                        while (true)
                        {
                            Console.Clear();
                            Banner.bannerPlayGame();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.Write("\n\t\t\t\t\t   Enter your name: ");
                            playerName = Console.ReadLine();
                            Console.ResetColor();

                            if (!string.IsNullOrWhiteSpace(playerName) && playerName.All(char.IsLetter))
                                break;

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("\n\t\t\t\t   Invalid name! Press any key to try again...");
                            Console.ResetColor();
                            Console.ReadKey();
                        }

                        string difficulty;

                        while (true)
                        {
                            Console.Clear();
                            Banner.bannerPlayGame();
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine();
                            Console.WriteLine("        ===================================== CHOOSE COMPUTER DIFFICULTY ====================================");
                            Console.WriteLine("\n\t\t\t\t\t     [1] Easy\n");
                            Console.WriteLine("\t\t\t\t\t     [2] Medium\n");
                            Console.WriteLine("\t\t\t\t\t     [3] Impossible\n");

                            Console.Write("\n\t\t\t\t\t     Select difficulty: ");
                            difficulty = Console.ReadLine();
                            Console.ResetColor();

                            if (difficulty == "1" || difficulty == "2" || difficulty == "3")
                                break;

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("\n\t\t\t\tInvalid computer difficulty. Press any key to try again...");
                            Console.ResetColor();
                            Console.ReadKey();
                        }

                        Console.Clear();
                        PlayGame(playerName, "Computer", true, difficulty);
                        break;
                    }

                    else if (mode == "3")
                    {
                        return;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\n\t\t\t\tInvalid mode selection. Press any key to try again...");
                        Console.ResetColor();
                        Console.ReadKey();
                    }
                }

            }

        }

        static void PlayGame(string player1, string player2, bool isAI, string difficulty = "")
        {

            int player1Wins = 0, player2Wins = 0, round = 1, maxRounds = 5;
            Computer computer = new Computer();
            Board board = new Board();

            while (player1Wins < 3 && player2Wins < 3 && round <= maxRounds)
            {
                board.ResetBoard();
                bool gameRunning = true;

                while (gameRunning)
                {
                    Console.Clear();
                    PrintHeader(player1, player2, player1Wins, player2Wins, round, maxRounds, isAI, difficulty);
                    board.DisplayBoards();

                    string currentPlayer = board.GetCurrentPlayer() == 'X' ? player1 : player2;
                    Console.Write($"\n\t\t\t\t\t\t{currentPlayer}'s turn ({board.GetCurrentPlayer()}): ");

                    int position;
                    if (isAI && currentPlayer == "Computer")
                    {
                        System.Threading.Thread.Sleep(300);

                        position = difficulty switch
                        {
                            "1" => computer.GetEasyMove(board.GetBoard()),
                            "2" => computer.GetMediumMove(board.GetBoard(), 'O', 'X'),
                            "3" => computer.GetImpossibleMove(board.GetBoard(), 'O', 'X'),
                            _ => computer.GetEasyMove(board.GetBoard())
                        };

                    }
                    else
                    {
                        if (!int.TryParse(Console.ReadLine(), out position))
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("\n\t\t\t\t    Invalid input! Enter a number between 1 and 9.");
                            Console.ResetColor();
                            Console.ReadKey();
                            continue;
                        }
                    }

                    if (board.MakeMove(position))
                    {
                        Console.Clear();
                        PrintHeader(player1, player2, player1Wins, player2Wins, round, maxRounds, isAI, difficulty);
                        board.DisplayBoards();

                        if (board.CheckWin())
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine();
                            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                            Console.WriteLine($"  \t\t\t\t\t     {currentPlayer} WINS this round! ");
                            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                            Console.ResetColor();

                            if (board.GetCurrentPlayer() == 'X') player1Wins++;
                            else player2Wins++;

                            gameRunning = false;
                            round++;
                        }
                        else if (board.IsDraw())
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine();
                            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                            Console.WriteLine("\t\t\t\t\t     DRAW! This round is not counted");
                            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                            Console.WriteLine();
                            Console.ResetColor();
                            gameRunning = false;
                        }
                        else
                        {
                            board.SwitchPlayer();
                        }
                    }
                    else
                    {
                        Console.ReadKey();
                    }
                }

                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("\n\t\t\t\t\t     Press any key to continue...");
                Console.ResetColor();
                Console.ReadKey();
            }

            Console.Clear();
            Printwinner(player1, player2, player1Wins, player2Wins, isAI, difficulty);



        }

        static void PrintHeader(string player1, string player2, int player1Wins, int player2Wins, int round, int maxRounds, bool isAI, string difficulty)
        {
            Banner.bannerGameon();
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine($"\n                                               ROUND:      {round} / {maxRounds}                                \n");
            Console.WriteLine($"                                               PLAYERS:  {player1} - {player2}        ");
            Console.WriteLine("                                                         ╔═══════╗");
            Console.WriteLine($"                                               SCORE:    ║ {player1Wins} - {player2Wins} ║");
            Console.WriteLine("                                                         ╚═══════╝");

            if (isAI)
            {
                string difficultyText = difficulty switch
                {
                    "1" => "Easy",
                    "2" => "Medium",
                    "3" => "Impossible",
                    _ => "Unknown"
                };
                Console.WriteLine($"                                               AI Difficulty: {difficultyText}\n");
            }
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
        }

        static void Printwinner(string player1, string player2, int player1Wins, int player2Wins, bool isAI, string difficulty)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();
            Console.WriteLine("\t\t\t ██████╗  █████╗ ███╗   ███╗███████╗     ██████╗ ██╗   ██╗███████╗██████╗ ");
            Console.WriteLine("\t\t\t██╔════╝ ██╔══██╗████╗ ████║██╔════╝    ██╔═══██╗██║   ██║██╔════╝██╔══██╗");
            Console.WriteLine("\t\t\t██║  ███╗███████║██╔████╔██║█████╗      ██║   ██║██║   ██║█████╗  ██████╔╝");
            Console.WriteLine("\t\t\t██║   ██║██╔══██║██║╚██╔╝██║██╔══╝      ██║   ██║╚██╗ ██╔╝██╔══╝  ██╔══██╗");
            Console.WriteLine("\t\t\t╚██████╔╝██║  ██║██║ ╚═╝ ██║███████╗    ╚██████╔╝ ╚████╔╝ ███████╗██║  ██║");
            Console.WriteLine("\t\t\t ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝     ╚═════╝   ╚═══╝  ╚══════╝╚═╝  ╚═╝");

            Console.WriteLine("");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t\t\t\t\t\t      FINAL SCORE");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.ResetColor();
            Console.WriteLine($"\t\t\t\t\t\t{player1}: {player1Wins} | {player2}: {player2Wins}");

            Console.ForegroundColor = ConsoleColor.DarkGreen;
            if (player1Wins >= 3)
                Console.WriteLine($"\n\t\t\t\t\t\t{player1} is the WINNER!");
            else if (player2Wins >= 3)
                Console.WriteLine($"\n\t\t\t\t\t\t{player2} is the WINNER!");
            else
                Console.WriteLine("  NO WINNER!");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\n\n\t\t\tPress 'Y' to play again, or any other key to return to the game selection menuu.");
            char playAgainChoice = Console.ReadKey().KeyChar;
            Console.ResetColor();

            if (char.ToUpper(playAgainChoice) == 'Y')
            {
                PlayGame(player1, player2, isAI, difficulty);
            }
        }
    
        static void PrintSelectionMode()
        {
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("        ========================================= SELECT GAME MODE ==========================================");
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t\t\t[1] Player vs Player\n");
            Console.WriteLine("\t\t\t\t\t\t[2] Player vs AI\n");
            Console.WriteLine("\t\t\t\t\t\t[3] Main Menu\n");
            Console.WriteLine();
            Console.Write("\t\t\t\t\t\tSelect mode: ");
            Console.ResetColor();
        }

    }
}

